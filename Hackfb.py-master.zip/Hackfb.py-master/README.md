# Hackfb.py

$ pkg update && pkg upgrade
$ pip2 install mechanize
$ pkg install request
$ pkg install nano
$ pkg install python2
$ pkg install php
$ pkg install git
$ git clone https://github.com/Alafasy441/hackFb.py
$ Is
$ python2 hackFb.py
